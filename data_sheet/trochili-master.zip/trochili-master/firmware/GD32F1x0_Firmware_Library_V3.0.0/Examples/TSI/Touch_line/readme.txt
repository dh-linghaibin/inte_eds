/*!
    \file  readme.txt
    \brief description of touch line
*/

/*
    Copyright (C) 2016 GigaDevice

    2014-12-26, V1.0.0, firmware for GD32F1x0(x=3,5)
    2016-01-15, V2.0.0, firmware for GD32F1x0(x=3,5,7,9)
    2016-04-30, V3.0.0, firmware update for GD32F1x0(x=3,5,7,9)
*/
  
  This demo is based on the GD32150R-EVAL board, it shows how to use the TSI to 
perform continuous acquisitions of three channels in group 5. In this demo, slide
the Touch Sensor on the GD32150R-EVAL board, meanwhile, light the LED1��LED2��LED3
and LED4 in trun.With a finger touch the Touch Sensor.
