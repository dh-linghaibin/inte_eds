/*!
    \file  readme.txt
    \brief description of touch key
*/

/*
    Copyright (C) 2016 GigaDevice

    2014-12-26, V1.0.0, firmware for GD32F1x0(x=3,5)
    2016-01-15, V2.0.0, firmware for GD32F1x0(x=3,5,7,9)
    2016-04-30, V3.0.0, firmware update for GD32F1x0(x=3,5,7,9)
*/
  
  This demo is based on the GD32190R-EVAL board, it shows how to use the TSI to 
perform continuous acquisitions of two channels in group 2. In this demo, touch
the TouchKey(TK1 or TK2) on the GD32190R-EVAL board, meanwhile, the associated 
LED(LED1 or LED2) is on.

