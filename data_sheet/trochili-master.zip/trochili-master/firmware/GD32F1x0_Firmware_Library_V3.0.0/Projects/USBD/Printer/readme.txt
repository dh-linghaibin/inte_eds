/*!
    \file  readme.txt
    \brief description of the USB device printer example
*/

/*
    Copyright (C) 2016 GigaDevice

    2014-09-06, V1.0.0, firmware for GD32F150
    2016-01-15, V1.0.1, firmware for GD32F150
    2016-04-30, V3.0.0, firmware update for GD32F150
*/

  The demo provide a printer device.

  To test the demo, you can run printer demo,then you check it from device manager.