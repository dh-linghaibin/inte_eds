#ifndef _TCL_COLIBRI_KEY_H
#define _TCL_COLIBRI_KEY_H



#define KEY1 (1)
#define KEY2 (2)

void EvbKeyConfig(void);
int EvbKeyScan(void);

#endif /* _TCL_COLIBRI_KEY_H*/
