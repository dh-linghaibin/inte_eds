# trochili
Trochili is an open source RTOS that optimized for the embedded/iot devices.
it runs on low-power microcontrollers such as Cortex M.
